from dataclasses import dataclass


@dataclass
class CNJ:
    cnj: str
    status: str
    data: dict
